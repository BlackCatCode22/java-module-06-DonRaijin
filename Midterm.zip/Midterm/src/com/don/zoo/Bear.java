package com.don.zoo;

import java.time.LocalDate;

public class Bear extends Animal {

    private static int numOfBears = 0;

    public Bear(String sex, LocalDate birthDate, int weight, String name, String id,
                String color, String origin, LocalDate arrivalDate) {
        super(sex, birthDate, weight, name, id, color, origin, arrivalDate);
        numOfBears++;
    }

    public static int getNumOfBears() { return numOfBears; }

    @Override
    public String getSpecialFeature() {
        return "growl: grrr";
    }
}
