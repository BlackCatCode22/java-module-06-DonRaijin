package com.don.zoo;

import java.time.LocalDate;

public class Hyena extends Animal {

    private static int numOfHyenas = 0;

    public Hyena(String sex, LocalDate birthDate, int weight, String name, String id,
                 String color, String origin, LocalDate arrivalDate) {
        super(sex, birthDate, weight, name, id, color, origin, arrivalDate);
        numOfHyenas++;
    }

    public static int getNumOfHyenas() { return numOfHyenas; }

    @Override
    public String getSpecialFeature() {
        return "laugh: haha";
    }
}

