package com.don.zoo;

import java.util.ArrayList;

public class AnimalNameList {

    private final ArrayList<String> hyenaNames;
    private final ArrayList<String> lionNames;
    private final ArrayList<String> tigerNames;
    private final ArrayList<String> bearNames;

    public AnimalNameList() {
        this.hyenaNames = new ArrayList<>();
        this.lionNames = new ArrayList<>();
        this.tigerNames = new ArrayList<>();
        this.bearNames = new ArrayList<>();
    }

    public ArrayList<String> getHyenaNames() { return hyenaNames; }
    public ArrayList<String> getLionNames() { return lionNames; }
    public ArrayList<String> getTigerNames() { return tigerNames; }
    public ArrayList<String> getBearNames() { return bearNames; }
}
