package com.don.zoo;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

public class App {
    public static void main(String[] args) {

        // Create HashMap for each animal
        HashMap<String, Hyena> hyenaMap = new HashMap<>();
        HashMap<String, Lion> lionMap = new HashMap<>();
        HashMap<String, Tiger> tigerMap = new HashMap<>();
        HashMap<String, Bear> bearMap = new HashMap<>();

        String outputFilePath = "zooPopulation.txt"; // writable output file

        // Lists to store names from file
        ArrayList<String> hyenaNames = new ArrayList<>();
        ArrayList<String> lionNames = new ArrayList<>();
        ArrayList<String> tigerNames = new ArrayList<>();
        ArrayList<String> bearNames = new ArrayList<>();

        // Load names into the lists
        loadAnimalNames("animalNames.txt", hyenaNames, lionNames, tigerNames, bearNames);

        // Open the file that has the arriving animals
        File inputFile = new File("arrivingAnimals.txt");

        // Check if file exists
        if (!inputFile.exists()) {
            System.out.println("Error: arrivingAnimals.txt not found.");
            return;
        }

        // Read each line from the file
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            String line;

            while ((line = reader.readLine()) != null) {

                // Skip empty lines
                if (line.trim().isEmpty()) continue;

                String[] elements = line.split(", ");

                // Check if line has enough data
                if (elements.length < 6) {
                    System.out.println("Skipping bad line: " + line);
                    continue;
                }

                String[] first = elements[0].split(" ");

                // Check if first element has enough words
                if (first.length < 5) {
                    System.out.println("Skipping bad line: " + line);
                    continue;
                }

                int age = Integer.parseInt(first[0]);
                String sex = first[3];
                String species = first[4].toLowerCase();
                String season = elements[1].toLowerCase();
                String color = elements[2];
                int weight = Integer.parseInt(elements[3].split(" ")[0]);
                String origin = elements[4] + ", " + elements[5];

                LocalDate birthDate = generateBirthDate(age, season);
                LocalDate arrivalDate = LocalDate.now();

                // Hyena
                if (species.equals("hyena")) {
                    String name = getName(hyenaNames, Hyena.getNumOfHyenas());
                    String id = "Hy0" + (Hyena.getNumOfHyenas() + 1);
                    Hyena hyena = new Hyena(sex, birthDate, weight, name, id, color, origin, arrivalDate);
                    hyenaMap.put(hyena.getAniID(), hyena);
                }

                // Lion
                else if (species.equals("lion")) {
                    String name = getName(lionNames, Lion.getNumOfLions());
                    String id = "Li0" + (Lion.getNumOfLions() + 1);
                    Lion lion = new Lion(sex, birthDate, weight, name, id, color, origin, arrivalDate);
                    lionMap.put(lion.getAniID(), lion);
                }

                // Tiger
                else if (species.equals("tiger")) {
                    String name = getName(tigerNames, Tiger.getNumOfTigers());
                    String id = "Ti0" + (Tiger.getNumOfTigers() + 1);
                    Tiger tiger = new Tiger(sex, birthDate, weight, name, id, color, origin, arrivalDate);
                    tigerMap.put(tiger.getAniID(), tiger);
                }

                // Bear
                else if (species.equals("bear")) {
                    String name = getName(bearNames, Bear.getNumOfBears());
                    String id = "Be0" + (Bear.getNumOfBears() + 1);
                    Bear bear = new Bear(sex, birthDate, weight, name, id, color, origin, arrivalDate);
                    bearMap.put(bear.getAniID(), bear);
                }

                // If species is unknown
                else {
                    System.out.println("Unknown species: " + species);
                }
            }

        } catch (IOException | NumberFormatException e) {
            System.out.println("Error reading arrivingAnimals.txt: " + e.getMessage());
        }

        // Print all animals by group
        System.out.println("\nWelcome to my Zoo\n");
        System.out.println("Hyenas:");
        hyenaMap.values().forEach(System.out::println);
        System.out.println("\nLions:");
        lionMap.values().forEach(System.out::println);
        System.out.println("\nTigers:");
        tigerMap.values().forEach(System.out::println);
        System.out.println("\nBears:");
        bearMap.values().forEach(System.out::println);

        //  zooPopulation.txt output
        try (PrintWriter outputFile = new PrintWriter(outputFilePath)) {
            outputFile.println("Welcome to my Zoo");

            outputFile.println("\nHyenas:");
            hyenaMap.values().forEach(outputFile::println);

            outputFile.println("\nLions:");
            lionMap.values().forEach(outputFile::println);

            outputFile.println("\nTigers:");
            tigerMap.values().forEach(outputFile::println);

            outputFile.println("\nBears:");
            bearMap.values().forEach(outputFile::println);

            System.out.println("\nZoo population report written to " + outputFilePath);
        } catch (IOException e) {
            System.out.println("Error writing " + outputFilePath + ": " + e.getMessage());
        }
    }

    private static String getName(ArrayList<String> list, int index) {
        return (index < list.size()) ? list.get(index) : "Unknown";
    }

    private static LocalDate generateBirthDate(int age, String season) {
        Random rand = new Random();
        int year = LocalDate.now().getYear() - age;
        int month;

        if (season.equals("spring")) month = rand.nextInt(3) + 3;      // March-May
        else if (season.equals("summer")) month = rand.nextInt(3) + 6; // June-Aug
        else if (season.equals("fall")) month = rand.nextInt(3) + 9;   // Sep-Nov
        else if (season.equals("winter")) {
            int[] winterMonths = {12, 1, 2};
            month = winterMonths[rand.nextInt(3)];
        } else month = rand.nextInt(12) + 1; // Unknown season

        int day = rand.nextInt(Month.of(month).length(false)) + 1;
        return LocalDate.of(year, month, day);
    }

    private static void loadAnimalNames(String filename, ArrayList<String> hyenaNames,
                                        ArrayList<String> lionNames, ArrayList<String> tigerNames,
                                        ArrayList<String> bearNames) {
        File file = new File(filename);
        if (!file.exists()) {
            System.out.println("Error: animalNames.txt not found.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            ArrayList<String> currentList = null;

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                if (line.startsWith("Hyena")) currentList = hyenaNames;
                else if (line.startsWith("Lion")) currentList = lionNames;
                else if (line.startsWith("Tiger")) currentList = tigerNames;
                else if (line.startsWith("Bear")) currentList = bearNames;
                else if (currentList != null) {
                    String[] names = line.split(",\\s*");
                    for (String name : names) currentList.add(name.trim());
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading animalNames.txt: " + e.getMessage());
        }
    }
}

