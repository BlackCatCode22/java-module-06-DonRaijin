package com.don.zoo;

import java.time.LocalDate;

public class Lion extends Animal {

    private static int numOfLions = 0;

    public Lion(String sex, LocalDate birthDate, int weight, String name, String id,
                String color, String origin, LocalDate arrivalDate) {
        super(sex, birthDate, weight, name, id, color, origin, arrivalDate);
        numOfLions++;
    }

    public static int getNumOfLions() { return numOfLions; }

    @Override
    public String getSpecialFeature() {
        return "roar: rawrr";
    }
}
