package com.don.zoo;

import java.time.LocalDate;

public class Tiger extends Animal {

    private static int numOfTigers = 0;

    public Tiger(String sex, LocalDate birthDate, int weight, String name, String id,
                 String color, String origin, LocalDate arrivalDate) {
        super(sex, birthDate, weight, name, id, color, origin, arrivalDate);
        numOfTigers++;
    }

    public static int getNumOfTigers() { return numOfTigers; }

    @Override
    public String getSpecialFeature() {
        return "growl: meowww";
    }
}
