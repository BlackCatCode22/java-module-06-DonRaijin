package com.don.zoo;

import java.util.Date;
import java.text.SimpleDateFormat;

public class Utilities {

    public static String arrivalDate() {
        Date today = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        return formatter.format(today);
    }
}
